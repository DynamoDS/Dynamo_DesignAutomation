<!--- Autodesk.DesignScript.Geometry.TSpline.TSplineTopology.TPointVertices --->
<!--- 3JL6REDTXILJYKG3YL47NDNEA5YHNLEAYOO3JNMRUUBMWI4GDGHA --->
## In Depth
In the example below, a planar T-Spline surface with extruded, subdivided, and pulled vertices and faces is inspected with the `TSplineTopology.TPointVertices` node to check if any of its vertices are T-Points.

The nodes `TSplineVertex.UVNFrame` and `TSplineUVNFrame.Position` are used to highlight the T-Points in the surface.

___
## Example File

![TSplineTopology.TPointVertices](./3JL6REDTXILJYKG3YL47NDNEA5YHNLEAYOO3JNMRUUBMWI4GDGHA_img.jpg)