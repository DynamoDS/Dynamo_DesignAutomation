## In Depth
`PolySurface.SurfaceCount` returns the number of surface within the given PolySurface object.

In the example below, a PolySurface is created from a cuboid and the surface count is provided with `PolySurface.SurfaceCount`.
___
## Example File

![PolySurface.SurfaceCount](./Autodesk.DesignScript.Geometry.PolySurface.SurfaceCount_img.jpg)